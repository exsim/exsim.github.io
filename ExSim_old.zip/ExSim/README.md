For more info, visit https://exsim.me

Run ExSim.jar with GUI, or ExSimAPI.jar
If jar files doesn't run, use command prompt and cd/navigate inside
ExcitementSimulator
or
ExcitementSimulatorAPI

Then in the command prompt, type:
$ java main.main